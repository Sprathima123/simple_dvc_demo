create env

conda create -n wineq python=3.10 -y

conda activate wineq

pip install -r requirements.txt